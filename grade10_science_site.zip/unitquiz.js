
const unitQuestions = [
  { q: "What is an atom made of?", a: "protons, neutrons, electrons" },
  { q: "What is the boiling point of water in Celsius?", a: "100" },
  { q: "What organ pumps blood?", a: "heart" }
];
let index = 0, correct = 0;
function loadQuizQ() {
  if (index < unitQuestions.length) {
    document.getElementById('quiz-question').textContent = unitQuestions[index].q;
    document.getElementById('quiz-answer').value = "";
    document.getElementById('quiz-feedback').textContent = "";
    document.getElementById('quiz-progress').textContent = `Question ${index + 1} of ${unitQuestions.length}`;
  } else {
    const score = Math.round((correct / unitQuestions.length) * 100);
    document.getElementById('quiz-question').textContent = `Quiz Complete! Score: ${score}%`;
    document.getElementById('quiz-feedback').textContent = "";
    document.getElementById('quiz-progress').textContent = "";
  }
}
function submitQuizAnswer() {
  const user = document.getElementById('quiz-answer').value.trim().toLowerCase();
  const answer = unitQuestions[index].a.toLowerCase();
  if (user === answer) correct++;
  index++;
  loadQuizQ();
}
function restartQuiz() {
  index = 0;
  correct = 0;
  loadQuizQ();
}
window.onload = loadQuizQ;
