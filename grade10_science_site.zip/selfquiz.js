
const questions = [
  { q: "What gas do plants absorb during photosynthesis?", a: "carbon dioxide" },
  { q: "What is the powerhouse of the cell?", a: "mitochondria" },
  { q: "What force keeps us on Earth?", a: "gravity" }
];
let currentQ = 0;
function loadQuestion() {
  document.getElementById('feedback').textContent = "";
  document.getElementById('user-answer').value = "";
  document.getElementById('question-text').textContent = questions[currentQ].q;
}
function checkAnswer() {
  const userAns = document.getElementById('user-answer').value.trim().toLowerCase();
  const correctAns = questions[currentQ].a.toLowerCase();
  document.getElementById('feedback').textContent = userAns === correctAns ? "✅ Correct!" : `❌ Wrong! Answer: ${questions[currentQ].a}`;
}
function nextQuestion() {
  currentQ = (currentQ + 1) % questions.length;
  loadQuestion();
}
window.onload = loadQuestion;
