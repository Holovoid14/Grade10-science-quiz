
const flashcards = [
  { term: "Photosynthesis", definition: "Process plants use to convert sunlight into energy." },
  { term: "Mitosis", definition: "Type of cell division resulting in two identical cells." },
  { term: "Gravity", definition: "Force that attracts objects towards each other." }
];
let currentCard = 0;
let showingTerm = true;
function showCard() {
  const card = flashcards[currentCard];
  document.getElementById('flashcard-text').textContent = showingTerm ? card.term : card.definition;
}
function flipCard() {
  showingTerm = !showingTerm;
  showCard();
}
function nextCard() {
  currentCard = (currentCard + 1) % flashcards.length;
  showingTerm = true;
  showCard();
}
window.onload = showCard;
